package com.example.script.location;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class clientlocationdto {
	
	
		
		
		private Integer id;
		private String description;
		
}
