package com.example.script.scriptcharector;



import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class clientscriptcharectordto {
	private Long id;
	private String name;
	private Long scriptId;
}
