package com.example.script.time;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class clienttimedto {
	
	

		private Integer id;
	    private String description;
	   
	

}
